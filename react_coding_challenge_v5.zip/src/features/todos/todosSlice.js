import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";
import { baseUrl } from "../../api";

export const fetchTodos = createAsyncThunk(
  "todos/fetchTodos",
  async (arg, thunkAPI) => {
    try {
      const response = await axios.get(`${baseUrl}/todos`);
      return response.data;
    } catch (error) {
      return thunkAPI.rejectWithValue({ msg: "Unable to fetch" });
    }
  }
);

export const todosSlice = createSlice({
  name: "todos",
  initialState: {
    loading: false,
    todos: [],
    error: ""
  },
  reducers: {
    setTodos: (state, action) => {
      state.todos = action.payload;
    }
  },
  extraReducers: {
    [fetchTodos.pending]: (state, action) => {
      state.loading = true;
    },
    [fetchTodos.fulfilled]: (state, action) => {
      state.todos = action.payload;
      state.loading = false;
    },
    [fetchTodos.rejected]: (state, action) => {
      state.error = action.payload.msg;
      state.loading = false;
    }
  }
});

export const { setTodos } = todosSlice.actions;

export const selectTodos = ({ todos }) => todos;

export default todosSlice.reducer;
