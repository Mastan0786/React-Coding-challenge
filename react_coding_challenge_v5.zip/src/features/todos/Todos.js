/* eslint-disable */

import React, { useState, useEffect } from "react";
import { Form, Table } from "react-bootstrap";
import Todo from "../../components/Todo";
import { useSelector, useDispatch } from "react-redux";
import { fetchTodos, selectTodos, setTodos } from "./todosSlice";
import { fetchUserDetails } from "../user_details/userDetailsSlice";

const Todos = () => {
  const data = useSelector(selectTodos);
  const dispatch = useDispatch();

  const { todos } = data;

  const [search, setSearch] = useState("");
  const [currentPage, setCurrentPage] = useState(1);

  const rowsPerPage = 10;
  const indexOfLastItem = currentPage * rowsPerPage;
  const indexOfFirstItem = indexOfLastItem - rowsPerPage;

  let currentTodos = todos
    .filter((todo) => {
      if (search) {
        let status = todo.completed ? "complete" : "incomplete";

        if (
          todo.id == search ||
          todo.title.toLowerCase().includes(search.toLowerCase()) ||
          status === search.toLowerCase()
        ) {
          return todo;
        }
      } else {
        return todo;
      }
    })
    .slice(indexOfFirstItem, indexOfLastItem);

  useEffect(() => {
    dispatch(fetchTodos());
  }, []);

  useEffect(() => {
    if (search || search === "") setCurrentPage(1);
  }, [search]);

  const handleViewUser = (todo, userId) => {
    dispatch(fetchUserDetails({ todo, userId }));
  };

  const handleSorting = () => {
    let sortedTodos = [...todos];
    dispatch(setTodos(sortedTodos.reverse()));
    setCurrentPage(1);
  };

  return (
    <>
      <div className="sticky-top bg-white border-bottom">
        <div className="row p-4">
          <div className="col">
            <h3 className="fw-bold">Todos</h3>
          </div>
          <div className="col">
            <Form.Control
              type="text"
              className="rounded-pill custom-input"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Type here to serach"
            />
          </div>
        </div>
      </div>

      {currentTodos.length === 0 ? (
        <h2 className="text-muted user-select-none text-center p-4">
          Nothing available to display
        </h2>
      ) : (
        <div className="p-4">
          <Table responsive>
            <thead>
              <tr>
                <th className="custom-btn" onClick={handleSorting}>
                  Todo ID ↑↓
                </th>
                <th>Title</th>
                <th>Status</th>
                <th className="text-center">Action</th>
              </tr>
            </thead>
            <tbody>
              {currentTodos.map((todo) => (
                <Todo key={todo.id} todo={todo} onViewUser={handleViewUser} />
              ))}
            </tbody>
          </Table>

          {/* pagination */}
          {currentTodos.length >= 10 && (
            <div className="d-flex justify-content-between">
              {indexOfFirstItem !== 0 && (
                <p
                  className="pagination-btn"
                  onClick={() => setCurrentPage((prev) => prev - 1)}
                >
                  ← Prev
                </p>
              )}
              {indexOfLastItem !== todos.length && (
                <p
                  className="pagination-btn"
                  onClick={() => setCurrentPage((prev) => prev + 1)}
                >
                  Next →
                </p>
              )}
            </div>
          )}
        </div>
      )}
    </>
  );
};

export default Todos;
