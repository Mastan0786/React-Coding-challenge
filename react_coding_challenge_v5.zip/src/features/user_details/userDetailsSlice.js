import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";
import { baseUrl } from "../../api";

export const fetchUserDetails = createAsyncThunk(
  "user_details/fetchUserDetails",
  async ({ todo, userId }, thunkAPI) => {
    try {
      const response = await axios.get(`${baseUrl}/users/${userId}`);

      return {
        todoId: todo.id,
        todoTitle: todo.title,
        userId: response.data.id,
        name: response.data.name,
        email: response.data.email
      };
    } catch (error) {
      return thunkAPI.rejectWithValue({ msg: "Unable to fetch" });
    }
  }
);

export const userDetailsSlice = createSlice({
  name: "user_details",
  initialState: {
    loading: false,
    user_details: {},
    error: ""
  },
  extraReducers: {
    [fetchUserDetails.pending]: (state, action) => {
      state.loading = true;
    },
    [fetchUserDetails.fulfilled]: (state, action) => {
      state.user_details = action.payload;
      state.loading = false;
    },
    [fetchUserDetails.rejected]: (state, action) => {
      state.error = action.payload.msg;
      state.loading = false;
    }
  }
});

export const selectUserDetails = ({ user_details }) => user_details;

export default userDetailsSlice.reducer;
