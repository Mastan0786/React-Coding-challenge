import React from "react";
import { Spinner } from "react-bootstrap";
import { useSelector } from "react-redux";
import { selectUserDetails } from "./userDetailsSlice";

const UserDetails = () => {
  const data = useSelector(selectUserDetails);

  const { loading, user_details, error } = data;

  return (
    <div className="p-4">
      {!loading && Object.keys(user_details).length === 0 && !error && (
        <h2 className="text-muted user-select-none text-center">
          No such user_details available to display
        </h2>
      )}

      {loading ? (
        <div className="d-flex justify-content-center">
          <Spinner animation="grow" variant="dark" className="spinner" />
        </div>
      ) : error ? (
        <h2 className="text-muted user-select-none text-center">{error}</h2>
      ) : (
        Object.keys(user_details).length > 0 && (
          <>
            <h3 className="fw-bold">User Details</h3>

            <pre className="p-4 mt-4 bg-dark text-white rounded-3">
              {JSON.stringify(user_details, null, 2)}
            </pre>
          </>
        )
      )}
    </div>
  );
};

export default UserDetails;
