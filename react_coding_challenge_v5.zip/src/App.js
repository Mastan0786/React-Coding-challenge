import React from "react";
import Todos from "./features/todos/Todos";
import UserDetails from "./features/user_details/UserDetails";

const App = () => {
  return (
    <div className="row g-0">
      <div className="col-md-6 g-0">
        <Todos />
      </div>
      <div className="col-md-6 g-0 custom-bg custom-container">
        <div className="sticky-top">
          <UserDetails />
        </div>
      </div>
    </div>
  );
};

export default App;
