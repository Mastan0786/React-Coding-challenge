import { configureStore } from "@reduxjs/toolkit";
import todosReducer from "../features/todos/todosSlice";
import userDetailsReducer from "../features/user_details/userDetailsSlice";

export default configureStore({
  reducer: {
    todos: todosReducer,
    user_details: userDetailsReducer
  }
});
