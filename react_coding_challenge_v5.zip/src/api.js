export const baseUrl = "https://jsonplaceholder.typicode.com";
