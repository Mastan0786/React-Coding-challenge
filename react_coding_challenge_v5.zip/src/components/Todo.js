import React from "react";
import { Button } from "react-bootstrap";

const Todo = ({ todo, onViewUser }) => {
  const { userId, id, title, completed } = todo;

  return (
    <tr className="align-middle">
      <td>{id}</td>
      <td>{title.length >= 30 ? title.slice(0, 30) + "..." : title}</td>
      <td>{completed ? "Complete" : "Incomplete"}</td>
      <td className="text-center">
        <Button variant="dark" onClick={() => onViewUser(todo, userId)}>
          View User
        </Button>
      </td>
    </tr>
  );
};

export default Todo;
